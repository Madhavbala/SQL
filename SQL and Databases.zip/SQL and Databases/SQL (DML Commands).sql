CREATE DATABASE demo2;               -- Create a daabase
USE demo2;                           -- Select the database

CREATE TABLE employee(emp_id INT,
					  first_name VARCHAR(50),
					  last_name VARCHAR(50),
                      age INT,
                      address VARCHAR(100),
                      salary INT);

DESC employee;

/* ===========================================================
DML Commands (Data Manipulation Language)
INSERT
UPDATE
DELETE
*/

/*==========================================================
Insert Command

INSERT INTO table_name 
VALUES(value1, value2, value3...);

INSERT INTO table_name (column1, column2, column3...)
VALUES(value1, value2, value3...);

INSERT INTO table_name (column1, column2, column3...)
VALUES(value1, value2, value3...),
	  (value1, value2, value3...),
      (value1, value2, value3...);
*/

SELECT * FROM employee;          -- Used to retrive data
INSERT INTO employee
VALUES(101, 'Aditya', 'Sirsat', 35, 'Delhi', 60000);

SELECT * FROM employee;
INSERT INTO employee
VALUES(102, 'Aniket', 'Giri', 39, 'Dehradun', 50000);

INSERT INTO employee (emp_id, first_name, last_name, age, address, salary)
VALUES(103, 'Anish', 'Jha', 49, 'Kolkata', 55000);

INSERT INTO employee (emp_id, first_name, last_name, address, salary, age)
VALUES(104, 'Anuj', 'Pratap', 'Kolkata', 55000, 48);

INSERT INTO employee (emp_id, first_name, address, salary)
VALUES(105, 'Aparna', 'Bangalore', 80000);

-- Inserting multiple rows
INSERT INTO employee (emp_id, first_name, last_name, age, address, salary)
VALUES(106, 'Arun', 'Kumar', 29, 'Karachi', 15000),
	  (107, 'Avdhoot', 'Barve', 34, 'Dhaka', 35000),
      (108, 'Awdesh', 'Pal', 45, 'Ghaziabad', 45000);
      
SELECT * FROM employee;

/*===================================================
UPDATE Command:
UPDATE table_name
SET column1 = value1, column2 = value2......
WHERE condition;
*/

-- SET SQL_SAFE_UPDATES = 0;              to turn off safe updates

UPDATE employee
SET salary = 45000
WHERE emp_id = 107;

SELECT * FROM employee;

UPDATE employee
SET last_name = 'Tadas' , age = 39
WHERE emp_id = 105;

UPDATE employee
SET address = 'Lahore'
WHERE first_name = 'Avdhoot' and last_name = 'Barve';

UPDATE employee
SET address = 'Pune'
WHERE address = 'Kolkata';

SELECT * FROM employee;


/*=============================================
DELETE Command:
DELETE FROM table_name
WHERE condition;
*/

DELETE FROM employee
WHERE emp_id = 106;

SELECT * FROM employee;

DELETE FROM employee
WHERE salary < 60000;

SELECT * FROM employee;

/*=========================================================*/
TRUNCATE TABLE employee;
SELECT * FROM employee;

DROP TABLE employee;
SHOW TABLES;