SHOW DATABASES;

/*
======= DDL Commands (Data Definition Language) ==========
CREATE
ALTER
DROP
TRUNCATE
*/

/*
Creating a database :
CREATE DATABASE database_name;
*/

CREATE DATABASE demo2;

SHOW DATABASES;

/*
Deleting a database
DROP DATABASE database_name;
*/

DROP DATABASE demo2;
SHOW DATABASES;

/*
IF EXISTS 
IF NOT EXISTS
*/

CREATE DATABASE demo2;
CREATE DATABASE demo2;                  -- Error

CREATE DATABASE IF NOT EXISTS demo2;    -- No error

DROP DATABASE demo10;                   -- Error
DROP DATABASE IF EXISTS demo10;         -- NO Error

/*=========================================================================
To create a table first select a database where a table has to be created
Command to select a database:
USE database_name

Creating a table:
CREATE TABLE table_name(column1 datatype,
                        column2 datatype,
                        column3 datatype);
*/

/* ================================
		MySQL Data Types
   ================================*/
/* A database table contains multiple columns with specific data types such as numeric or string or date. 
MySQL provides more data types other than just numeric and string. Each data type in MySQL 
can be determined by the following characteristics:

> The kind of values it represents.
> The space that takes up and whether the values are a fixed-length or variable length.

Data types are grouped into five categories:
1. Numeric Data Types
2. String Data Types
3. Date and Time data types
4. Spatial Data Types
5. JSON Data Types
*/

CREATE DATABASE demo1;     -- Create a database
USE demo1;                 -- Select/Use the database

CREATE TABLE student(first_name VARCHAR(50),
					 last_name VARCHAR(50),
                     age INT,
                     city VARCHAR(100));
SHOW TABLES;        -- Show tables
DESC student;       -- Schema of a table

/*
Deleting a table
DROP TABLE table_name
*/

CREATE TABLE temp(name VARCHAR(100));
SHOW TABLES;

DROP TABLE temp;
SHOW TABLES;


/* ================================================================
ALTER command     (Changing schema of a table)
ALTER TABLE table_name
.........................;

- Adding a new column
- Droping a column
- Changing name of a column
- Changing data type of a column
- Changing name of a table
*/
USE demo1;
DESC student;

ALTER TABLE student           -- Adding column
ADD dob DATE;

DESC student;

ALTER TABLE student          -- Deleting a column
DROP COLUMN dob;

DESC student;

ALTER TABLE student        	-- Rename a column
RENAME COLUMN city TO address;

DESC student;

ALTER TABLE student
MODIFY address VARCHAR(200); -- Modify the data type

DESC student;

ALTER TABLE student
RENAME TO employee;

DESC employee;

/*
TRUNCATE Command:
Truncate command deletes the data inside a Table
Whereas drop command deletes the whole table itself
*/