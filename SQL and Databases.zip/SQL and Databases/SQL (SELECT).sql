SHOW DATABASES;
CREATE DATABASE IF NOT EXISTS demo1;
USE demo1;

DROP TABLE IF EXISTS employee;

CREATE TABLE employee(
			empid INT PRIMARY KEY,
            fname VARCHAR(50) NOT NULL,
            lname VARCHAR(50),
            gender CHAR(1),
            city VARCHAR(100) DEFAULT 'Jaipur',
            salary INT,
            department VARCHAR(50));
            
DESC employee;

INSERT INTO employee(empid, fname, lname, gender, city, salary, department)
VALUES (101, 'Akshita', 'BC', 'F', 'Delhi', 60000, 'Marketing'),
	   (102, 'Ankit', 'Das', 'M', 'Kolkata', 80000, 'Finance'),
       (103, 'Ankita', 'Gangurde', 'F', 'Pune', 75000, 'Engineering'),
       (104, 'Ankur', 'Varshney', 'M', 'Gaziabad', 90000, 'Research'),
       (105, 'Utkarsh', 'Sharma', 'M', 'Jaipur', 400000, 'Research'),
       (106, 'Madhu','Bagri','F', 'Mumbai',82000,'Engineering'),
	   (107, 'Mahtab', 'Alam','M', 'Hyderabad', 85000,'Marketing'),
       (108, 'Tanya', 'Bajaj','F','Panipat', 80000,'HR'),
	   (109,'Tarun', 'Shah', 'M','Jaipur', 75000,'Finance'),
       (110, 'Rishabh', 'Sharma', 'M', 'Indore',60000,'HR'),
       (111,'Rupa', 'Datta', 'F', 'Pune', 750000, 'Marketing'),
       (112,'Uma', 'Dev', 'F', 'Hyderabad', 50000, 'Finance'),
       (113,'Kumar', 'Sharma', 'M', 'Mumbai', 60000, 'Marketing'),
       (114,'Naresh', 'Avasthi', 'M', 'Pune', 750000, 'Finance'),
       (115,'Paul', 'Dave', 'M', 'Pune', 750000, 'Engineering'),
       (116, 'Kim', 'Yan', 'F', 'Mumbai', 30770, 'Marketing'),
	   (117, 'Sam', 'Das', 'M', 'Jaipur', 22000, 'Management'),
	   (118, 'Omy', 'Shah', 'F', 'Delhi', 45000, 'Finance'),
	   (119, 'Tom', 'Fox', 'M', 'Kanpur', 150000, 'Finance'),
	   (120, 'Jon', 'Cox', 'M', 'Mumbai', 24250, 'HR'),
       (121,'Madhu','BG','F','Bangalore',60000,'R&D'),
	   (122,'Kirti','Binani', 'F','Kolkata',55000,'Finance'),
	   (123, 'Govind', 'Chandak','M','Balasore',80000,'Engineering'),
	   (124, 'Suman','Ch','F','Kolkata',45000,'Accounting'),
	   (125,'Bharat','Bag' ,'M','Bangalore',100000,'Sales'),
       (126, 'Abhishek', 'Kumar', 'M', 'Hyderabad', 60000, 'Marketing'),
       (127, 'Mayank', 'Sharma', 'M', 'Delhi', 75000, 'Accounting'),
       (128, 'Shivangi', 'Shreya', 'F', 'Ranchi', 80000, 'Engineering'),
       (129, 'Rahul', 'Bhalotiya', 'M', 'Jamshedpur', 50000, 'Engineering'),
       (130, 'Dayanidhi', 'Dahima', 'M', 'Delhi', 90000, 'Sales'),
       (131,'Avadhut','Madane','M','Pune',20000,'Finance'),
	   (132,'Rahul','Kokare','M','Baramati',30000,'Accounting'),
       (133,'Suhas','Zunjar','M','Indapur',35000,'Marketing'),
       (134,'Sanjay','Tangade','M','Solapur',25000,'HR'),
       (135,'Vijay','Kokare','M','Sangali',45000,'R&D');
       
SELECT * FROM employee;           -- * : All columns
       
SELECT fname FROM employee;
       
SELECT empid, fname, lname, salary FROM employee;
       
SELECT department FROM employee;
SELECT DISTINCT department FROM employee;       -- Distinct values
SELECT DISTINCT city FROM employee;
       
/*=========================================== WHERE ==================================================*/
SELECT * FROM employee;

SELECT * FROM employee
WHERE department = 'Finance';

SELECT empid, fname, lname, department FROM employee
WHERE department = 'Finance';

SELECT * FROM employee
WHERE salary >= 100000;

SELECT * FROM employee
WHERE salary > 100000 and department = 'Finance';

SELECT * FROM employee
WHERE city = 'Delhi' or city = 'Jaipur';

SELECT * FROM employee
WHERE salary >= 80000 and salary <= 150000;

SELECT * FROM employee
WHERE salary BETWEEN 80000 and 150000;

SELECT * FROM employee
WHERE city = 'Delhi' or city = 'Jaipur' or city = 'Pune' or city = 'Mumbai';

SELECT * FROM employee
WHERE city IN ('Delhi', 'Jaipur', 'Pune', 'Mumbai');

SELECT * FROM employee
WHERE city NOT IN ('Delhi', 'Jaipur', 'Pune', 'Mumbai');

SELECT * FROM employee
WHERE fname LIKE 'A%';                -- First name staring with A

SELECT * FROM employee
WHERE fname LIKE '%t';                -- First name ending with t

SELECT * FROM employee                
WHERE city LIKE '%pur';               -- City ending with pur

/* ========================================== ORDER BY ================================================ */
SELECT * FROM employee
ORDER BY salary;                                        -- By default ascending order

SELECT * FROM employee
ORDER BY salary ASC;                                    -- For ascending order

SELECT * FROM employee
ORDER BY salary DESC;                                   -- For descending order

SELECT * FROM employee
ORDER BY fname; 

SELECT * FROM employee
ORDER BY fname DESC;

SELECT * FROM employee
ORDER BY salary ASC, fname ASC;

SELECT * FROM employee
WHERE department = 'Finance'
ORDER BY salary;

SELECT * FROM employee
WHERE gender = 'M'
ORDER BY salary;

SELECT * FROM employee
WHERE gender = 'M' and salary > 80000
ORDER BY salary;

/* ======================================= LIMIT =========================================== */
SELECT * FROM employee
LIMIT 5;                            # Only extract 5 rows

SELECT * FROM employee
LIMIT 3;

SELECT * FROM employee
WHERE gender = 'M'
LIMIT 3;

SELECT * FROM employee
ORDER BY salary
LIMIT 3;

SELECT * FROM employee
WHERE gender = 'M'
ORDER BY salary
LIMIT 3;

-- Extract employees with highest 3 salaries
SELECT * FROM employee
ORDER BY salary DESC
LIMIT 3;

-- Extract employees with lowest 3 salaries
SELECT * FROM employee
ORDER BY salary ASC
LIMIT 3;

-- Extract the employee having lowest salary
SELECT * FROM employee
ORDER BY salary ASC
LIMIT 1;

-- Extract the employee having highest salary
SELECT * FROM employee
ORDER BY salary DESC
LIMIT 1;

-- LIMIT a,b   (Skip a number of rows and extract b number of rows)
SELECT * FROM employee
LIMIT 5,5;

-- Extract the employee having second lowest salary
SELECT * FROM employee
ORDER BY salary ASC
LIMIT 1,1;

-- Extract the employee having second highest salary
SELECT * FROM employee
ORDER BY salary DESC
LIMIT 1,1;

-- Extract the employee having third highest salary
SELECT * FROM employee
ORDER BY salary DESC
LIMIT 2,1;

-- Extract the employee having fourth lowest salary
SELECT * FROM employee
ORDER BY salary ASC
LIMIT 3,1;

/* ======================================= Aggregate Functions ======================================= 
COUNT()    -   Returns Number of rows
SUM()      -   Returns the sum
AVG()      -   Returns The average
MIN()      -   Returns the minimum value
MAX()      -   Returns the maximum value
*/

SELECT COUNT(*) FROM employee;         -- Number of employees

SELECT COUNT(*) FROM employee
WHERE department = 'Finance';          -- Number of employees in the finance department

SELECT COUNT(DISTINCT department) FROM employee; -- Numbert of departments

SELECT COUNT(*) FROM employee
WHERE salary >= 100000;                -- Number of employees making more than 100000

SELECT SUM(salary) FROM employee;      -- Sum of salaries

SELECT SUM(salary) FROM employee
WHERE department = 'Finance';

SELECT SUM(salary) FROM employee
WHERE gender = 'M';

SELECT AVG(salary) FROM employee;      -- Average salary of employees

SELECT AVG(salary) FROM employee
WHERE gender = 'M';                    -- Average salary of males

SELECT AVG(salary) FROM employee
WHERE gender = 'F';                    -- Average salary of females

SELECT AVG(salary) FROM employee
WHERE gender = 'F' and department = 'Marketing';   -- Average salary of female employees in marketing department

SELECT AVG(salary) FROM employee
WHERE gender = 'M' and department = 'Marketing';   -- Average salary of male employees in marketing department

SELECT MAX(salary) FROM employee;          -- Highest salary

SELECT MAX(salary) FROM employee
WHERE department = 'Research';          -- Max salary in the research department

SELECT MAX(salary) FROM employee
WHERE department = 'Marketing';        -- Highest salary in the marketing department

SELECT MIN(salary) FROM employee;      -- Lowest salary

SELECT MIN(salary) FROM employee
WHERE department = 'Marketing';        -- Lowest salary in marketing deartment


/* ======================================= GROUP BY ============================================ */
SELECT department, COUNT(*) FROM employee
GROUP BY department;                             -- Number of employees in each department

SELECT department, COUNT(*) AS no_of_employees FROM employee
GROUP BY department;

SELECT city, COUNT(*) AS no_of_employees FROM employee
GROUP BY city;                                   -- Number of employees in each city

SELECT department , AVG(salary) AS avg_salary FROM employee
GROUP BY department;                              -- Average salary in each department

SELECT department , AVG(salary) AS avg_salary FROM employee
GROUP BY department
ORDER BY avg_salary DESC;                         -- Average salary in each department in descending order

-- Extract department having top three average salaries
SELECT department , AVG(salary) AS avg_salary FROM employee
GROUP BY department
ORDER BY avg_salary DESC
LIMIT 3;

-- Extract city having highest avg salary
SELECT city, AVG(salary) AS avg_salary FROM employee
GROUP BY city
ORDER BY avg_salary DESC
LIMIT 1;

-- Extract highest paid employees from each department in descnding order
SELECT department, MAX(salary) AS max_salary FROM employee
GROUP BY department
ORDER BY max_salary DESC;

-- Extract average salary of males in each department in descending order
SELECT department, AVG(salary) as avg_salary FROM employee
WHERE gender = 'M'
GROUP BY department
ORDER BY avg_salary DESC;

-- Extract average salary of females in each department in descending order
SELECT department, AVG(salary) as avg_salary FROM employee
WHERE gender = 'F'
GROUP BY department
ORDER BY avg_salary DESC;

-- ================= HAVING ===================

-- Extarct average salary in each city
SELECT city, AVG(salary) AS avg_salary FROM employee
GROUP BY city;

-- Extract all the cities having average salaries more than 100000
SELECT city, AVG(salary) AS avg_salary FROM employee
GROUP BY city
HAVING avg_salary > 100000;      -- Having is used to mention a condition after group by

-- Extract departments having average female salaries more than 60000 in descending order
SELECT department, AVG(salary) AS avg_salary FROM employee
WHERE gender = 'F'
GROUP BY department
HAVING avg_salary > 60000
ORDER BY avg_salary DESC;

-- Extract departments having average salary between 80000 to 200000
SELECT department, AVG(salary) AS avg_salary FROM employee
GROUP BY department
HAVING avg_salary BETWEEN 80000 AND 200000;

/* =======================================================
SELECT    -----------------
WHERE     -----------------
GROUP BY  -----------------
HAVING    -----------------
ORDER BY  -----------------
LIMIT     -----------------
======================================================= */

/* ============================ SUB QUERIES =========================== */

-- Extarct all employees having salary greater than the average salary

SELECT AVG(salary) FROM employee;
SELECT * FROM employee
WHERE salary > 130543;

SELECT * FROM employee
WHERE salary > (SELECT AVG(salary) FROM employee);

CREATE TABLE male_employees(
						empid INT PRIMARY KEY,
						fname VARCHAR(50) NOT NULL,
						lname VARCHAR(50),
						gender CHAR(1),
						city VARCHAR(100) DEFAULT 'Jaipur',
						salary INT,
						department VARCHAR(50));
                        
INSERT INTO male_employees
SELECT * FROM employee
WHERE gender = 'M';

SELECT * FROM male_employees;