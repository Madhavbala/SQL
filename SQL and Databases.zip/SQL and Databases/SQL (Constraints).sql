/*
MySql Constraints

CREATE TABLE table_name (
	column1 datatype constraint,
    column2 datatype constraint,
    column3 datatype constraint,
    --------------------------
    );
    
Constrains:
> NOT NULL    - Null values not allowed
> UNIQUE      - Duplicate values not allowed
> DEFAULT     - Allows to specify default value for a column
> PRIMARY KEY - Uniquely identifies each row in the table
> FOREIGN KEY - Maitaining or establishing links between tables
> CHECK       - To apply conditions
*/

USE demo1;

SHOW TABLES;
DROP TABLE IF EXISTS employee;

CREATE TABLE employee(emp_id INT UNIQUE NOT NULL,
					  fname VARCHAR(50) NOT NULL,
                      lname VARCHAR(50),
                      city VARCHAR(100) DEFAULT 'Bangalore',
                      age INT CHECK (age > 21));
                      
DESC employee;

INSERT INTO employee (emp_id, fname, lname, city, age)
VALUES (101, 'Arun', 'Kumar', 'Delhi', 45);

INSERT INTO employee (emp_id, fname, lname, city, age)
VALUES (102, 'Aparna', 'Tadas', 'Kolkata', 49);

SELECT * FROM employee;

INSERT INTO employee (emp_id, fname, lname, city, age)
VALUES (102, 'Gayatri', 'Pandey', 'Agra', 39);            -- Error : Duplicate employee id (UNIQUE)

INSERT INTO employee (emp_id, fname, city, age)
VALUES (103, 'Gayatri', 'Agra', 39);

SELECT * FROM employee;

INSERT INTO employee (emp_id, lname, city, age)
VALUES (104, 'Wasekar', 'Agra', 59);                       -- Error : fname cant be null (DEFAULT)

INSERT INTO employee (emp_id, fname, lname, city, age)
VALUES (104, 'Bhushan', 'Wasekar', 'Agra', 59);

INSERT INTO employee (emp_id, fname, lname, age)
VALUES (105, 'Dharini', 'Sriram',  29);                    -- Default value Bangalore will be taken

SELECT * FROM employee;

INSERT INTO employee (emp_id, fname, lname, city, age)
VALUES (106, 'Varshita', 'Shrikar', 'Mumbai', 19);         -- Error : Check constraint violated